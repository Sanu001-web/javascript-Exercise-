# ShaanFitness upgrade

## What's included
- Existing ShaanFitness site retained; added Student Kitchen and Food Tracker pages.
- Public recipe search and filters with 10 affordable Indian recipe examples.
- Supabase Auth wiring for existing login/signup forms when configured.
- Member-only diary writes/reads through Supabase `food_entries` with RLS.
- SQL schema and profile trigger in `supabase/schema.sql`.

## Setup
1. Create a Supabase project.
2. Open SQL Editor and run `supabase/schema.sql`.
3. In Project Settings → API, copy the Project URL and anon/publishable key.
4. Put those two public values in `script/supabase-config.js`.
5. Deploy the folder to a static host over HTTPS.

Never use the Supabase `service_role` key in browser code or commit it to GitHub.
Enable email confirmation in Supabase Auth if desired. Configure your deployed site URL and redirect URLs in Supabase Auth URL settings.

## Important current limitations
- Student Kitchen currently uses a bundled JavaScript seed list for public browsing. The SQL `recipes` table is ready for a future admin-managed recipe catalogue, but the current UI does not yet fetch recipes from that table.
- Food Tracker currently supports adding recipe servings and reading daily entries. Entry editing/deletion, custom foods, food catalogue selection, target editing, favorites, and historical charts are not implemented in this first pass.
- Macro and cost values are approximate illustrative estimates per serving, not medical or dietetic advice.
- The previous browser-local account system remains in the original script as a legacy fallback when Supabase is not configured. Do not use that fallback for real member data or production authentication. Configure Supabase before enabling member access.
- Static chart values and existing sample dashboard figures have not been converted into real member data.

## Existing files preserved
Original visual identity and existing sections remain in place. Main page now references the actual `style/shaanfitness.css` and `script/shaanfitness.js` paths from this repository.
