
-- ShaanFitness Supabase schema (run in Supabase SQL Editor).
-- Public recipe content is readable by everyone; diary rows are private to their owner.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  first_name text,
  last_name text,
  phone text,
  created_at timestamptz not null default now()
);

create table if not exists public.recipes (
  id text primary key,
  name text not null,
  category text not null,
  description text,
  servings integer not null default 1,
  estimated_cost_inr numeric(8,2),
  calories numeric(8,2),
  protein_g numeric(8,2),
  carbs_g numeric(8,2),
  fat_g numeric(8,2),
  ingredients jsonb not null default '[]'::jsonb,
  instructions jsonb not null default '[]'::jsonb,
  is_published boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.food_catalog (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  serving_label text not null default '100 g',
  calories numeric(8,2) not null default 0,
  protein_g numeric(8,2) not null default 0,
  carbs_g numeric(8,2) not null default 0,
  fat_g numeric(8,2) not null default 0,
  is_published boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.food_entries (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  entry_date date not null default current_date,
  meal_type text not null check (meal_type in ('Breakfast','Lunch','Dinner','Snack')),
  food_name text not null,
  quantity numeric(8,2) not null check (quantity > 0),
  calories numeric(10,2) not null default 0,
  protein_g numeric(10,2) not null default 0,
  carbs_g numeric(10,2) not null default 0,
  fat_g numeric(10,2) not null default 0,
  source_type text check (source_type in ('recipe','catalog','custom')),
  source_id text,
  created_at timestamptz not null default now()
);

create table if not exists public.favorite_recipes (
  user_id uuid not null references auth.users(id) on delete cascade,
  recipe_id text not null references public.recipes(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_id, recipe_id)
);

alter table public.profiles enable row level security;
alter table public.recipes enable row level security;
alter table public.food_catalog enable row level security;
alter table public.food_entries enable row level security;
alter table public.favorite_recipes enable row level security;

create policy "Users can read own profile" on public.profiles for select to authenticated using (auth.uid() = id);
create policy "Users can insert own profile" on public.profiles for insert to authenticated with check (auth.uid() = id);
create policy "Users can update own profile" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);
create policy "Published recipes are public" on public.recipes for select using (is_published = true);
create policy "Published food catalogue is public" on public.food_catalog for select using (is_published = true);
create policy "Users read own food entries" on public.food_entries for select to authenticated using (auth.uid() = user_id);
create policy "Users insert own food entries" on public.food_entries for insert to authenticated with check (auth.uid() = user_id);
create policy "Users update own food entries" on public.food_entries for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users delete own food entries" on public.food_entries for delete to authenticated using (auth.uid() = user_id);
create policy "Users manage own favorites" on public.favorite_recipes for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Create a profile row automatically after a new auth account is created.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles (id, first_name, last_name, phone)
  values (new.id, new.raw_user_meta_data->>'first_name', new.raw_user_meta_data->>'last_name', new.raw_user_meta_data->>'phone')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

-- The front-end Student Kitchen currently uses a bundled recipe seed for fast public browsing.
-- Admins can add reviewed recipes through the Supabase dashboard; do not expose admin/service keys in the browser.
